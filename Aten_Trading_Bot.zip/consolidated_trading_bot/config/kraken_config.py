# Placeholder for KRAKEN API Keys
# Replace with your actual Kraken API key and secret.
# IMPORTANT: Do not commit your actual API keys to version control.

KRAKEN_API_KEY = "YOUR_KRAKEN_API_KEY"
KRAKEN_API_SECRET = "YOUR_KRAKEN_API_SECRET"

# Other configurations can be added here, for example:
# - Trading pairs to focus on
# - Risk management parameters (e.g., max_trade_size_pct_balance)
# - Timeframes for analysis
# - Model file names if different from default

TRADING_PAIRS = ["BTC/USD", "ETH/USD"] # Example, user should configure
DEFAULT_TIMEFRAME = "5m"
MODEL_NAME = "trading_model.h5" # Default model name used by signal_generator

