"""
Main entry point for the Aten Trading Bot package.
This allows the bot to be run with 'python -m aten_bot
"""

from aten_bot.core.main_bot import run_trading_bot

if __name__ == "__main__":
    run_trading_bot()
