import logging
import os
import time
import pandas as pd # Added for reading CSV for pattern recognizer

# Configure logging for the main application
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(module)s - %(message)s')
logger = logging.getLogger(__name__)

# Import bot components
from ..config.kraken_config import KRAKEN_API_KEY, KRAKEN_API_SECRET, TRADING_PAIRS, DEFAULT_TIMEFRAME, MODEL_NAME
from .kraken_executor import KrakenExecutor
from .data_downloader import DataDownloader
from .model_trainer import train_model
from .signal_generator import generate_signal_for_symbol
from .pattern_recognizer import recognize_candlestick_patterns

# Define paths relative to the aten_bot package
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")
MODEL_DIR = os.path.join(BASE_DIR, "models")
MODEL_PATH = os.path.join(MODEL_DIR, MODEL_NAME)

def ensure_directories():
    """Ensures that necessary directories exist."""
    os.makedirs(DATA_DIR, exist_ok=True)
    os.makedirs(MODEL_DIR, exist_ok=True)
    logger.info(f"Ensured directories exist: {DATA_DIR}, {MODEL_DIR}")

def run_trading_bot():
    """Main function to run the trading bot workflow."""
    logger.info("Starting the Consolidated Trading Bot...")
    ensure_directories()

    if KRAKEN_API_KEY == "YOUR_KRAKEN_API_KEY" or KRAKEN_API_SECRET == "YOUR_KRAKEN_API_SECRET":
        logger.warning("Kraken API keys are not configured in config/kraken_config.py. Live trading functions will fail. Proceeding with simulated/test mode where possible.")
        executor = None
    else:
        executor = KrakenExecutor(api_key=KRAKEN_API_KEY, api_secret=KRAKEN_API_SECRET)
        if executor.kraken:
            logger.info("Kraken Executor initialized.")
        else:
            logger.error("Failed to initialize Kraken Executor. Check API keys and network.")
            executor = None

    downloader = DataDownloader(api_key=KRAKEN_API_KEY, api_secret=KRAKEN_API_SECRET)
    logger.info("Data Downloader initialized.")

    logger.info(f"Checking/Downloading data for pairs: {TRADING_PAIRS}")
    for pair in TRADING_PAIRS:
        pair_file_name = f"ohlcv_{DEFAULT_TIMEFRAME}_{pair.replace('/', '-')}.csv"
        pair_file_path = os.path.join(DATA_DIR, pair_file_name)
        if not os.path.exists(pair_file_path) or os.path.getsize(pair_file_path) < 1000: # Ensure file exists and has some data
            logger.info(f"Data for {pair} not found or insufficient at {pair_file_path}. Downloading 200 candles...")
            downloader.fetch_and_save_ohlcv(symbol=pair, timeframe=DEFAULT_TIMEFRAME, limit=200)
            time.sleep(1) 
        else:
            logger.info(f"Data for {pair} found at {pair_file_path}.")

    if not os.path.exists(MODEL_PATH):
        logger.info(f"Model not found at {MODEL_PATH}. Training a new model...")
        if TRADING_PAIRS:
            training_data_file = f"ohlcv_{DEFAULT_TIMEFRAME}_{TRADING_PAIRS[0].replace('/', '-')}.csv"
            training_data_path = os.path.join(DATA_DIR, training_data_file)
            if os.path.exists(training_data_path):
                logger.info(f"Attempting to train model using {training_data_path}")
                success = train_model(data_filepath=training_data_path, model_save_name=MODEL_NAME, epochs=10)
                if not success:
                    logger.error("Model training failed. Bot cannot proceed with ML strategy.")
                    return
            else:
                logger.error(f"Training data {training_data_path} not found. Cannot train model.")
                return
        else:
            logger.error("No trading pairs defined for training. Cannot train model.")
            return
    else:
        logger.info(f"Using existing model: {MODEL_PATH}")

    logger.info("--- Generating Trading Signals & Recognizing Patterns ---")
    signals_with_patterns = []
    for pair in TRADING_PAIRS:
        logger.info(f"Processing pair: {pair}...")
        signal = generate_signal_for_symbol(symbol=pair, model_name=MODEL_NAME, ohlcv_timeframe=DEFAULT_TIMEFRAME)
        
        if signal:
            logger.info(f"ML Signal for {pair}: {signal}")
            ohlcv_df_path = os.path.join(DATA_DIR, f"ohlcv_{DEFAULT_TIMEFRAME}_{pair.replace('/', '-')}.csv")
            active_patterns_info = "No active patterns or data issue."
            if os.path.exists(ohlcv_df_path):
                try:
                    ohlcv_df = pd.read_csv(ohlcv_df_path)
                    ohlcv_df.columns = [str(col).lower() for col in ohlcv_df.columns]
                    if not ohlcv_df.empty:
                        patterns_df = recognize_candlestick_patterns(ohlcv_df)
                        if not patterns_df.empty:
                            latest_patterns_series = patterns_df.iloc[-1]
                            # Filter for columns that start with CDL_ and have non-zero values
                            active_patterns = {p: latest_patterns_series[p] for p in latest_patterns_series.index if p.startswith("CDL") and latest_patterns_series[p] != 0}
                            if active_patterns:
                                active_patterns_info = active_patterns
                                logger.info(f"Active candlestick patterns for {pair} at last candle: {active_patterns}")
                            else:
                                logger.info(f"No active candlestick patterns detected for {pair} at last candle.")
                        else:
                            logger.warning(f"Pattern DataFrame empty for {pair}.")
                    else:
                        logger.warning(f"OHLCV DataFrame empty for {pair} when reading for patterns.")
                except Exception as e_pattern:
                    logger.error(f"Error during pattern recognition for {pair}: {e_pattern}")
            else:
                logger.warning(f"OHLCV data file not found for pattern recognition: {ohlcv_df_path}")
            
            signal['patterns'] = active_patterns_info
            signals_with_patterns.append(signal)

            if executor and signal['action'] != 'HOLD':
                trade_amount = 0.0001 if pair == "BTC/USD" else (0.001 if pair == "ETH/USD" else 1)
                logger.info(f"Attempting to place {signal['action']} order for {trade_amount} of {pair} (SIMULATED/TEST)...")
                order_result = executor.place_market_order(
                    symbol=pair, 
                    side=signal['action'].lower(), 
                    amount=trade_amount,
                    params={'validate': 'true'} # TEST ORDER
                )
                logger.info(f"Test order placement result for {pair}: {order_result}")
        else:
            logger.info(f"No ML signal generated for {pair}.")
        time.sleep(0.5) # Small pause

    if not signals_with_patterns:
        logger.info("No trading signals were generated for any configured pair.")
    else:
        logger.info(f"--- Final Signals with Patterns ({len(signals_with_patterns)}) ---")
        for s in signals_with_patterns:
            logger.info(s)
    
    logger.info("Consolidated Trading Bot run finished.")

if __name__ == "__main__":
    run_trading_bot()

