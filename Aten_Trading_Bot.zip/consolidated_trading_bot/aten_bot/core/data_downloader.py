import ccxt
import pandas as pd
import time
import os
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(module)s - %(message)s')
logger = logging.getLogger(__name__)
# For standalone execution, this path might need adjustment or direct key provision.
try:
    from ..config.kraken_config import KRAKEN_API_KEY, KRAKEN_API_SECRET
except ImportError:
    logger.warning("Could not import Kraken API keys from config. Using public API methods only for downloader.")
    KRAKEN_API_KEY = None
    KRAKEN_API_SECRET = None

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")

# Settings from original script
DEFAULT_TIMEFRAMES = ["5m", "15m", "1h", "1d"]
DEFAULT_MIN_VOLUME_USD = 50000000  # $50 million USD minimum volume

class DataDownloader:
    def __init__(self, api_key: str | None = KRAKEN_API_KEY, api_secret: str | None = KRAKEN_API_SECRET):
        """Initialize the Kraken client."""
        kraken_config = {}
        if api_key and api_secret:
            kraken_config["apiKey"] = api_key
            kraken_config["secret"] = api_secret
        
        try:
            self.kraken = ccxt.kraken(kraken_config)
            if api_key and api_secret:
                 # Test connection if authenticated
                self.kraken.fetch_balance() 
            logger.info("Kraken client initialized for DataDownloader.")
        except Exception as e:
            logger.error(f"Failed to initialize Kraken client for DataDownloader: {e}. Public methods might still work.")
            # Fallback to a public client if authenticated fails
            self.kraken = ccxt.kraken() 

    def get_trading_pairs(self, min_volume_usd: float = DEFAULT_MIN_VOLUME_USD, quote_currency: str = "USD") -> list:
        """Fetches active trading pairs from Kraken filtered by minimum quote volume."""
        trading_pairs = []
        try:
            markets = self.kraken.load_markets()
            for symbol, market in markets.items():
               if market.get("quote") == quote_currency and market.get("active") and market.get("spot"):
                    try:
                        ticker = self.kraken.fetch_ticker(symbol)
                        # quoteVolume is the volume in terms of the quote currency
                        # baseVolume is the volume in terms of the base currency
                        # We use quoteVolume directly if available and represents USD volume.
                        # If quoteVolume is not directly USD volume, we might need baseVolume * price.
                        # For Kraken, ticker["quoteVolume"] is often the 24h volume in quote currency.
                        if ticker.get("quoteVolume") and ticker.get("quoteVolume") >= min_volume_usd:
                            trading_pairs.append(symbol)
                        elif ticker.get("baseVolume") and ticker.get("last") and (ticker["baseVolume"] * ticker["last"] >= min_volume_usd):                           trading_pairs.append(symbol)
                            
                    except ccxt.NetworkError as e_net:
                        logger.warning(f"Network error fetching ticker for {symbol}: {e_net}. Skipping symbol.")
                    except ccxt.ExchangeError as e_exc:
                        logger.warning(f"Exchange error fetching ticker for {symbol}: {e_exc}. Skipping symbol.")
                    except Exception as e_ticker:
                        logger.warning(f"Could not fetch or process ticker for {symbol}: {e_ticker}. Skipping symbol.")
            logger.info(f"Found {len(trading_pairs)} trading pairs meeting criteria: {trading_pairs}")
        except Exception as e:
            logger.error(f"Error loading markets or processing pairs: {e}")
        return trading_pairs

    def fetch_and_save_ohlcv(self, symbol: str, timeframe: str, limit: int = 1000, since: int | None = None) -> bool:
        """Fetches OHLCV data for a symbol and timeframe, then saves it to a CSV file."""
        try:
            if not os.path.exists(DATA_DIR):
                os.makedirs(DATA_DIR)
                logger.info(f"Created data directory: {DATA_DIR}")

            logger.info(f"Fetching OHLCV for {symbol} ({timeframe}), limit={limit}, since={since}")
            # ccxt fetch_ohlcv returns: [timestamp, open, high, low, close, volume]
            data = self.kraken.fetch_ohlcv(symbol, timeframe=timeframe, limit=limit, since=since)
            if not data:
                logger.warning(f"No OHLCV data returned for {symbol} ({timeframe}).")
                return False
            
            df = pd.DataFrame(data, columns=["timestamp", "open", "high", "low", "close", "volume"])
            df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms")
            # df["symbol"] = symbol # Symbol column can be useful if concatenating data later
            
            # Filename convention: ohlcv_{timeframe}_{symbol_sanitized}.csv
            symbol_sanitized = symbol.replace("/", "-")
            filename = f"ohlcv_{timeframe}_{symbol_sanitized}.csv"
            filepath = os.path.join(DATA_DIR, filename)
            
            df.to_csv(filepath, index=False)
            logger.info(f"Saved {len(df)} rows of OHLCV data to {filepath}")
            return True
        except ccxt.NetworkError as e_net:
            logger.error(f"Network error fetching OHLCV for {symbol} {timeframe}: {e_net}")
        except ccxt.ExchangeError as e_exc:
            logger.error(f"Exchange error fetching OHLCV for {symbol} {timeframe}: {e_exc}")
        except Exception as e:
            logger.error(f"Error fetching or saving OHLCV for {symbol} {timeframe}: {e}")
        return False

    def download_all_selected_pairs_data(self, 
                                         timeframes: list = DEFAULT_TIMEFRAMES, 
                                         min_volume_usd: float = DEFAULT_MIN_VOLUME_USD, 
                                         limit_per_fetch: int = 1000):
        """Downloads OHLCV data for all selected trading pairs and timeframes."""
        logger.info("Starting download process for all selected pairs data.")
        pairs = self.get_trading_pairs(min_volume_usd=min_volume_usd)
        if not pairs:
            logger.warning("No trading pairs found meeting criteria. No data will be downloaded.")
            return

        logger.info(f"Identified {len(pairs)} pairs for data download: {pairs}")
        for timeframe in timeframes:
            logger.info(f"--- Processing timeframe: {timeframe} ---")
            for symbol in pairs:
                self.fetch_and_save_ohlcv(symbol, timeframe, limit=limit_per_fetch)
                time.sleep(self.kraken.rateLimit / 1000 * 1.1) # Respect rate limits, add small buffer
        logger.info("Finished downloading data for all selected pairs and timeframes.")


if __name__ == "__main__":
    logger.info("Data Downloader script started directly.")
    downloader = DataDownloader()
    
    # Example: Download data for a few specific pairs and timeframes
    # downloader.fetch_and_save_ohlcv(\"BTC/USD\", \"5m\")
    # time.sleep(2)
    # downloader.fetch_and_save_ohlcv(\"ETH/USD\", \"5m\")
    
    # Example: Download all data according to default settings
    downloader.download_all_selected_pairs_data(limit_per_fetch=100) # smaller limit for example
    logger.info("Data Downloader script finished.")

