import pandas as pd
import numpy as np
import os
import logging
from datetime import datetime
from tensorflow.keras.models import load_model

# Assuming feature_generator is in the same directory or PYTHONPATH is set
from .feature_generator import create_features

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(module)s - %(message)s')
logger = logging.getLogger(__name__)
MODEL_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "models")
DEFAULT_MODEL_NAME = "trading_model.h5"
DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")

def generate_signal_for_symbol(symbol: str, model_name: str = DEFAULT_MODEL_NAME, ohlcv_timeframe: str = '5m') -> dict | None:
    """
    Generates a trading signal for a single cryptocurrency symbol.

    Args:
        symbol (str): The trading symbol (e.g., 'BTC-USD').
        model_name (str): The filename of the trained Keras model.
        ohlcv_timeframe (str): The timeframe for OHLCV data (e.g., '5m', '1h').

    Returns:
        dict | None: A dictionary containing the signal (timestamp, symbol, action, confidence, price)
                     or None if a signal cannot be generated.
    """
    model_path = os.path.join(MODEL_DIR, model_name)
    if not os.path.exists(model_path):
        logger.error(f"Model file not found: {model_path}")
        return None
    try:
        model = load_model(model_path)
        logger.info(f"Successfully loaded model: {model_path}")
    except Exception as e:
        logger.error(f"Error loading model {model_path}: {e}")
        return None

    # Construct filename based on convention from download_ohlcv_data.py (e.g., ohlcv_5m_BTC-USD.csv)
    # The original generate_signals.py used symbol like BTC-USD directly in filename.
    # The download_ohlcv_data.py saves as ohlcv_5m_BTC-USD.csv (replacing / with -)
    filename = f"ohlcv_{ohlcv_timeframe}_{symbol.replace('/', '-')}.csv"
    filepath = os.path.join(DATA_DIR, filename)

    if not os.path.exists(filepath):
        logger.warning(f"No OHLCV data file found for {symbol} at {filepath}. Attempting generic ohlcv.csv if symbol is general.")
        # Fallback for general ohlcv.csv if specific symbol file not found (less ideal)
        if symbol == 'ohlcv': # a generic name, not a pair
            filepath = os.path.join(DATA_DIR, 'ohlcv.csv')
            if not os.path.exists(filepath):
                 logger.error(f"Generic OHLCV data file not found: {filepath}")
                 return None
        else:
            logger.error(f"Specific OHLCV data file not found: {filepath}")
            return None
            
    try:
        df_ohlcv = pd.read_csv(filepath)
        df_ohlcv.columns = [str(col).lower() for col in df_ohlcv.columns]
        logger.info(f"Loaded OHLCV data for {symbol} from {filepath}. Shape: {df_ohlcv.shape}")
    except Exception as e:
        logger.error(f"Error loading OHLCV data for {symbol} from {filepath}: {e}")
        return None

    if len(df_ohlcv) < 50: # Arbitrary minimum data length for feature generation
        logger.warning(f"Not enough data for {symbol} to generate features. Found {len(df_ohlcv)} rows.")
        return None

    try:
        df_features_full = create_features(df_ohlcv)
        logger.info(f"Features created for {symbol}. Shape: {df_features_full.shape}")
    except Exception as e:
        logger.error(f"Error creating features for {symbol}: {e}")
        return None

    if df_features_full.empty:
        logger.warning(f"Feature DataFrame is empty for {symbol} after creation.")
        return None

    # Select the same feature columns used during training
    feature_columns = [
        "ema_9", "ema_21", "rsi", "macd", "macd_signal_line", "macd_diff",
        "volume_avg_10", "candle_size", "bb_mavg", "bb_hband", "bb_lband", 
        "bb_pband", "bb_wband", "stoch_k", "stoch_d"
    ]
    
    missing_feature_cols = [col for col in feature_columns if col not in df_features_full.columns]
    if missing_feature_cols:
        logger.error(f"Missing feature columns for prediction in {symbol}: {missing_feature_cols}. Available: {df_features_full.columns.tolist()}")
        return None

    latest_features_df = df_features_full[feature_columns].iloc[-1:] # Get the most recent row of features
    
    if latest_features_df.empty:
        logger.warning(f"No valid latest features for {symbol} after selection.")
        return None

    X_latest = latest_features_df.values

    try:
        predictions_proba = model.predict(X_latest)
        prediction_class = np.argmax(predictions_proba, axis=1)[0]
        confidence = float(np.max(predictions_proba))
        logger.info(f"Prediction for {symbol}: Class={prediction_class}, Confidence={confidence:.4f}")
    except Exception as e:
        logger.error(f"Error during model prediction for {symbol}: {e}")
        return None

    # Map class to action (0=sell, 1=hold, 2=buy)
    action_map = {0: 'SELL', 1: 'HOLD', 2: 'BUY'}
    action = action_map.get(prediction_class, 'UNKNOWN')

    current_price = df_ohlcv['close'].iloc[-1]

    signal = {
        'timestamp': datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S'),
        'symbol': symbol,
        'action': action,
        'confidence': round(confidence * 100, 2),
        'price': float(current_price) # Ensure price is a float
    }
    logger.info(f"Generated signal for {symbol}: {signal}")
    return signal

def generate_signals_for_all_pairs(model_name: str = DEFAULT_MODEL_NAME, ohlcv_timeframe: str = '5m') -> list:
    """Generates signals for all available OHLCV data files in the data directory."""
    signals = []
    processed_symbols = set()

    if not os.path.exists(DATA_DIR):
        logger.error(f"Data directory not found: {DATA_DIR}")
        return []

    for filename in os.listdir(DATA_DIR):
        if filename.startswith(f"ohlcv_{ohlcv_timeframe}_") and filename.endswith(".csv"):
            try:
                # Extract symbol from filename like ohlcv_5m_BTC-USD.csv
                parts = filename.replace(f"ohlcv_{ohlcv_timeframe}_", "").replace(".csv", "")
                symbol = parts # This should be the pair like BTC-USD
                if symbol not in processed_symbols:
                    logger.info(f"Processing symbol: {symbol} from file: {filename}")
                    signal = generate_signal_for_symbol(symbol, model_name, ohlcv_timeframe)
                    if signal:
                        signals.append(signal)
                    processed_symbols.add(symbol)
            except Exception as e:
                logger.error(f"Error processing file {filename}: {e}")
                continue
                
    if not signals:
        logger.info("No signals generated for any pair.")
    else:
        logger.info(f"Generated {len(signals)} signals in total.")
    return signals

if __name__ == "__main__":
    logger.info("Running example signal generation...")
    
    # Ensure a model is trained and available, and data exists
    # Example: Train a model first if it doesn\t exist
    if not os.path.exists(os.path.join(MODEL_DIR, DEFAULT_MODEL_NAME)):
        logger.warning(f"Default model {DEFAULT_MODEL_NAME} not found. Attempting to train a test model.")
        from model_trainer import train_model
        sample_data_path = os.path.join(DATA_DIR, "ohlcv_5m_BTC-USD.csv") # Make sure this exists
        if os.path.exists(sample_data_path):
            train_model(sample_data_path, model_save_name=DEFAULT_MODEL_NAME, epochs=5)
        else:
            logger.error(f"Sample data for training {sample_data_path} not found. Cannot generate signals without a model.")

    # Generate signal for a specific symbol
    btc_signal = generate_signal_for_symbol('BTC-USD')
    if btc_signal:
        print(f"BTC-USD Signal: {btc_signal}")
    else:
        print("Could not generate signal for BTC-USD.")

    # Generate signals for all pairs
    all_signals = generate_signals_for_all_pairs()
    if all_signals:
        print(f"\nAll Generated Signals ({len(all_signals)}):")
        for s in all_signals:
            print(s)
    else:
        print("\nNo signals generated for any pair.")

