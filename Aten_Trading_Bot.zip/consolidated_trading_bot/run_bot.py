"""
Entry point for the Aten Trading Bot.

This script serves as the main entry point for running the Aten Trading Bot.
It initializes the bot and starts the trading process.
"""

from aten_bot.core.main_bot import run_trading_bot

if __name__ == "__main__":
    print("Starting Aten Trading Bot...")
    run_trading_bot()
    print("Aten Trading Bot execution completed.")
