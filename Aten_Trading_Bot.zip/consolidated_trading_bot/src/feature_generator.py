import pandas as pd
import numpy as np
import ta
import logging

# Configure logging
logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(module)s - %(message)s')

def create_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Generates technical indicator features for the given OHLCV DataFrame.
    Input DataFrame must have 'open', 'high', 'low', 'close', 'volume' columns.
    """
    logger.info(f"Starting feature creation for DataFrame with shape {df.shape}")
    df_copy = df.copy()

    # Ensure required columns are present
    required_cols = ['open', 'high', 'low', 'close', 'volume']
    if not all(col in df_copy.columns for col in required_cols):
        missing_cols = [col for col in required_cols if col not in df_copy.columns]
        logger.error(f"Missing required columns in input DataFrame: {missing_cols}")
        raise ValueError(f"DataFrame must contain columns: {required_cols}")

    # Basic cleaning
    df_copy = df_copy.dropna(subset=required_cols)
    df_copy.reset_index(drop=True, inplace=True)

    if df_copy.empty:
        logger.warning("DataFrame is empty after initial NaN drop.")
        return pd.DataFrame() # Return empty if no data to process

    # Technical Indicators
    try:
        df_copy['ema_9'] = ta.trend.ema_indicator(df_copy['close'], window=9)
        df_copy['ema_21'] = ta.trend.ema_indicator(df_copy['close'], window=21)
        df_copy['rsi'] = ta.momentum.rsi(df_copy['close'], window=14)

        macd_ind = ta.trend.MACD(df_copy['close'])
        df_copy['macd'] = macd_ind.macd()
        df_copy['macd_signal_line'] = macd_ind.macd_signal() # Renamed 'signal' to 'macd_signal_line' to avoid conflict if 'signal' is a target
        df_copy['macd_diff'] = macd_ind.macd_diff() # MACD histogram

        df_copy['volume_avg_10'] = df_copy['volume'].rolling(window=10).mean()
        df_copy['candle_size'] = df_copy['high'] - df_copy['low']
        
        # Bollinger Bands
        bollinger = ta.volatility.BollingerBands(close=df_copy['close'], window=20, window_dev=2)
        df_copy['bb_mavg'] = bollinger.bollinger_mavg()
        df_copy['bb_hband'] = bollinger.bollinger_hband()
        df_copy['bb_lband'] = bollinger.bollinger_lband()
        df_copy['bb_pband'] = bollinger.bollinger_pband()
        df_copy['bb_wband'] = bollinger.bollinger_wband()

        # Stochastic Oscillator
        stoch = ta.momentum.StochasticOscillator(high=df_copy['high'], low=df_copy['low'], close=df_copy['close'], window=14, smooth_window=3)
        df_copy['stoch_k'] = stoch.stoch()
        df_copy['stoch_d'] = stoch.stoch_signal()

    except Exception as e:
        logger.error(f"Error calculating technical indicators: {e}")
        # Depending on policy, either raise or return partially processed df or empty
        raise

    # Drop NaNs from all the indicators
    df_copy.dropna(inplace=True)
    df_copy.reset_index(drop=True, inplace=True)

    logger.info(f"Feature creation completed. Output DataFrame shape: {df_copy.shape}")
    
    # Select features for the model (as used in the original train_model.py from Crypto_trading_bot)
    # Original features: ['ema_9', 'ema_21', 'rsi', 'macd', 'signal', 'volume_avg', 'candle_size', 'close']
    # We will keep 'close' for now as it was in the original feature set for training, 
    # but it's typically removed before feeding to model.predict().
    # The model_trainer.py should handle the final feature selection for X.
    
    # For now, returning all generated features plus original OHLCV for flexibility
    # The calling function (model_trainer or signal_generator) will select the exact columns needed.
    return df_copy

if __name__ == '__main__':
    # Example Usage (requires a sample CSV file)
    try:
        sample_df = pd.read_csv('../data/ohlcv_5m_BTC-USD.csv') # Adjust path as needed
        # Ensure columns are lowercase if necessary
        sample_df.columns = [str(col).lower() for col in sample_df.columns]
        features_df = create_features(sample_df)
        print("Sample features generated:")
        print(features_df.head())
        print(f"Columns in features_df: {features_df.columns.tolist()}")
    except FileNotFoundError:
        logger.warning("Sample data file not found. Skipping example usage in feature_generator.py.")
    except Exception as e:
        logger.error(f"Error in feature_generator.py example usage: {e}")

