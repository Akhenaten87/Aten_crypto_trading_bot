import pandas as pd
import pandas_ta as ta # Import pandas_ta
import logging
import os

# Configure logging
logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(module)s - %(message)s') Get a list of all available candlestick patterns in pandas_ta
# This can be done by inspecting pandas_ta.candles.cdl_doji.df.ta.cdl_pattern(name="all") or similar
# For simplicity, we can try to recognize all available or a curated list.
# pandas_ta.candles.SUPPORTED_CDL_PATTERNS can be a source if available, or we list common ones.
# As of pandas_ta 0.3.14b0, df.ta.cdl_pattern(name=\"all\") is a good way.

def recognize_candlestick_patterns(df_ohlcv: pd.DataFrame) -> pd.DataFrame:
    """
    Recognizes all available candlestick patterns using pandas_ta for the given OHLCV DataFrame.
    Input DataFrame must have \'open\
 \'high\
 \'low\
 \'close\' columns (lowercase).
    pandas_ta expects columns named \'open\
 \'high\
 \'low\
 \'close\
 \'volume\'.

    Args:
        df_ohlcv (pd.DataFrame): DataFrame with OHLCV data.

    Returns:
        pd.DataFrame: Original DataFrame with added columns for each recognized pattern.
                       Pattern columns will contain pandas_ta\s integer codes (e.g., 100 for bullish, -100 for bearish, 0 for none).
    """
    logger.info(f"Starting candlestick pattern recognition with pandas_ta for DataFrame with shape {df_ohlcv.shape}")
    df_patterns = df_ohlcv.copy()

    required_cols = [\"open\", \"high\", \"low\", \"close\"] # Volume might be used by some ta features but not directly by cdl patterns
    if not all(col in df_patterns.columns for col in required_cols):
        missing_cols = [col for col in required_cols if col not in df_patterns.columns]
        logger.error(f"Missing required OHLC columns for pattern recognition: {missing_cols}")
        raise ValueError(f"DataFrame must contain columns: {required_cols}")

    # Ensure data types are float for pandas_ta candlestick functions
    for col in required_cols:
        df_patterns[col] = pd.to_numeric(df_patterns[col], errors=\'coerce\
    
    df_patterns.dropna(subset=required_cols, inplace=True) # Drop rows if essential OHLC data is NaN after conversion
    if df_patterns.empty:
        logger.warning("DataFrame is empty after ensuring numeric OHLC and dropping NaNs. Cannot recognize patterns.")
        return df_patterns

    # Use pandas_ta to find all candlestick patterns
    # This will add columns for each pattern found (e.g., CDL_DOJI, CDL_HAMMER, etc.)
    try:
        # Ensure the DataFrame has the correct column names expected by pandas_ta (lowercase)
        # df_patterns.columns = [col.lower() for col in df_patterns.columns]
        # The above line is already done in signal_generator and model_trainer when loading CSV.
        
        # Using df.ta.cdl_pattern(name="all") might create many columns.
        # Let\s select a few common and useful patterns to demonstrate.
        # Alternatively, use name="all" to get all supported by pandas_ta.
        # common_patterns = ["doji", "hammer", "engulfing", "morningstar", "eveningstar"]
        # for pattern_name in common_patterns:
        #     df_patterns.ta.cdl_pattern(name=pattern_name, append=True)

        # The most straightforward way to get all patterns is:
        df_patterns.ta.cdl_pattern(name="all", append=True)
        logger.info(f"pandas_ta cdl_pattern(name=\"all\") applied. Columns added.")
        
    except Exception as e:
        logger.error(f"Error calculating patterns with pandas_ta: {e}", exc_info=True)
        # If it fails, the DataFrame might be partially modified or not at all.
        # For safety, we might return the original df or raise the error.
        # For now, we log and continue, the df might have some pattern columns or none.

    logger.info(f"Candlestick pattern recognition with pandas_ta completed. Output DataFrame shape: {df_patterns.shape}")
    return df_patterns

if __name__ == \"__main__\":
    logger.info("Running example pattern recognition with pandas_ta...")
    try:
        sample_data_dir = \"../data\"
        if not os.path.exists(sample_data_dir):
            os.makedirs(sample_data_dir)
        
        sample_file_path = os.path.join(sample_data_dir, \"sample_ohlcv_for_patterns.csv\")
        if not os.path.exists(sample_file_path):
            logger.info(f"Sample data file {sample_file_path} not found. Creating one.")
            sample_data = {
                \"timestamp\": pd.to_datetime([\"2023-01-01 00:00:00\", \"2023-01-01 00:05:00\", \"2023-01-01 00:10:00\", \"2023-01-01 00:15:00\", \"2023-01-01 00:20:00\
                                 \"2023-01-01 00:25:00\", \"2023-01-01 00:30:00\", \"2023-01-01 00:35:00\", \"2023-01-01 00:40:00\", \"2023-01-01 00:45:00\"]),
                \"open\": [100, 102, 101, 105, 103, 104, 102, 100, 98, 99],
                \"high\": [103, 104, 106, 106, 105, 105, 103, 101, 99, 101],
                \"low\": [99, 101, 100, 102, 102, 101, 99, 98, 97, 98],
                \"close\": [102, 101, 105, 103, 104, 102, 100, 99, 98, 100],
                \"volume\": [1000, 1200, 1100, 1500, 1300, 1400, 1000, 900, 1100, 1200]
            }
            pd.DataFrame(sample_data).to_csv(sample_file_path, index=False)
            logger.info(f"Created sample data file: {sample_file_path}")

        sample_df = pd.read_csv(sample_file_path)
        # pandas_ta expects lowercase column names
        sample_df.columns = [str(col).lower() for col in sample_df.columns]
        
        patterns_df = recognize_candlestick_patterns(sample_df)
        print("Sample patterns recognized with pandas_ta:")
        
        # Print only columns that are candlestick patterns (usually start with CDL_)
        pattern_cols = [col for col in patterns_df.columns if col.startswith(\"CDL\")]
        if pattern_cols:
            # Display rows where at least one pattern is active
            active_pattern_rows = patterns_df[patterns_df[pattern_cols].abs().sum(axis=1) > 0]
            if not active_pattern_rows.empty:
                print(active_pattern_rows[["timestamp\", "open\", "high\", "low\", "close\"] + pattern_cols].tail())
            else:
                print("No active patterns recognized in the sample data with pandas_ta.")
        else:
            print("No candlestick pattern columns (starting with CDL_) found after processing.")
        print(f"\nAll columns in patterns_df: {patterns_df.columns.tolist()}")

    except ImportError:
        logger.error("pandas_ta is not installed. Please install it to use the pattern recognizer. (e.g., pip install pandas_ta)")
    except FileNotFoundError:
        logger.warning(f"Sample data file not found. Skipping example usage in pattern_recognizer.py.")
    except Exception as e:
        logger.error(f"Error in pattern_recognizer.py example usage: {e}", exc_info=True)

