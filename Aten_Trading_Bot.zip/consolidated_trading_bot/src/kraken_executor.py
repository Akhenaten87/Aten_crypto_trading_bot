import ccxt
import logging

# Configure logging
logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

class KrakenExecutor:
    def __init__(self, api_key: str, api_secret: str):
        """Initialize the Kraken client with API credentials."""
        try:
            self.kraken = ccxt.kraken({
                'apiKey': api_key,
                'secret': api_secret,
                'enableRateLimit': True, # Recommended for production use
            })
            self.kraken.load_markets() # Load markets at initialization
            logger.info("Kraken client initialized successfully.")
        except Exception as e:
            logger.error(f"Failed to initialize Kraken client: {e}")
            self.kraken = None

    def get_account_balance(self) -> dict:
        """Fetch and return the total balance of the Kraken account."""
        if not self.kraken:
            logger.error("Kraken client not initialized.")
            return {}
        try:
            balance = self.kraken.fetch_balance()
            logger.info(f"Successfully fetched account balance.")
            return balance.get('total', {})
        except ccxt.NetworkError as e:
            logger.error(f"Kraken API NetworkError fetching balance: {e}")
            return {}
        except ccxt.ExchangeError as e:
            logger.error(f"Kraken API ExchangeError fetching balance: {e}")
            return {}
        except Exception as e:
            logger.error(f"Failed to fetch account balance: {e}")
            return {}

    def get_ticker_price(self, symbol: str) -> float | None:
        """Fetch and return the current price of a trading pair (e.g., 'BTC/USD')."""
        if not self.kraken:
            logger.error("Kraken client not initialized.")
            return None
        try:
            ticker = self.kraken.fetch_ticker(symbol)
            price = ticker.get('last')
            if price is not None:
                logger.info(f"Successfully fetched ticker price for {symbol}: {price}")
            else:
                logger.warning(f"Could not retrieve 'last' price for {symbol} from ticker: {ticker}")
            return price
        except ccxt.NetworkError as e:
            logger.error(f"Kraken API NetworkError fetching ticker for {symbol}: {e}")
            return None
        except ccxt.ExchangeError as e:
            logger.error(f"Kraken API ExchangeError fetching ticker for {symbol}: {e}")
            return None
        except Exception as e:
            logger.error(f"Failed to fetch ticker price for {symbol}: {e}")
            return None

    def place_market_order(self, symbol: str, side: str, amount: float, params={}) -> dict:
        """
        Place a market order.
        :param symbol: e.g., 'BTC/USD'
        :param side: 'buy' or 'sell'
        :param amount: quantity of asset to trade
        :param params: Additional parameters for the order (e.g., {'validate': True} for testing)
        """
        if not self.kraken:
            logger.error("Kraken client not initialized.")
            return {}
        try:
            order = self.kraken.create_market_order(symbol, side, amount, params=params)
            logger.info(f"Market {side} order placed for {amount} of {symbol}: {order.get('id')}")
            return order
        except ccxt.InsufficientFunds as e:
            logger.error(f"Insufficient funds to place market {side} order for {amount} of {symbol}: {e}")
            return {}
        except ccxt.InvalidOrder as e:
            logger.error(f"Invalid market {side} order for {amount} of {symbol}: {e}")
            return {}
        except ccxt.NetworkError as e:
            logger.error(f"Kraken API NetworkError placing order for {symbol}: {e}")
            return {}
        except ccxt.ExchangeError as e:
            logger.error(f"Kraken API ExchangeError placing order for {symbol}: {e}")
            return {}
        except Exception as e:
            logger.error(f"Failed to place market order for {symbol}: {e}")
            return {}

    def get_open_orders(self, symbol: str | None = None) -> list:
        """Fetch open orders. Optionally filter by symbol."""
        if not self.kraken:
            logger.error("Kraken client not initialized.")
            return []
        try:
            open_orders = self.kraken.fetch_open_orders(symbol)
            logger.info(f"Successfully fetched {len(open_orders)} open orders" + (f" for {symbol}" if symbol else ""))
            return open_orders
        except ccxt.NetworkError as e:
            logger.error(f"Kraken API NetworkError fetching open orders: {e}")
            return []
        except ccxt.ExchangeError as e:
            logger.error(f"Kraken API ExchangeError fetching open orders: {e}")
            return []
        except Exception as e:
            logger.error(f"Failed to fetch open orders: {e}")
            return []

    def cancel_all_orders(self, symbol: str | None = None) -> dict:
        """Cancel all open orders, optionally for a specific symbol."""
        if not self.kraken:
            logger.error("Kraken client not initialized.")
            return {}
        try:
            # ccxt's cancel_all_orders might not support symbol for all exchanges, 
            # but Kraken's API does. We might need to fetch and cancel one by one if not directly supported.
            # For now, assuming it works or we iterate if needed.
            if symbol and hasattr(self.kraken, 'cancel_all_orders_for_symbol'): # Hypothetical method
                 response = self.kraken.cancel_all_orders_for_symbol(symbol)
            elif symbol:
                # If no direct method, fetch open orders for symbol and cancel them individually
                open_orders = self.get_open_orders(symbol)
                cancelled_ids = []
                for order in open_orders:
                    try:
                        self.kraken.cancel_order(order['id'], symbol)
                        cancelled_ids.append(order['id'])
                    except Exception as e_cancel:
                        logger.error(f"Failed to cancel order {order['id']} for {symbol}: {e_cancel}")
                logger.info(f"Cancelled {len(cancelled_ids)} orders for {symbol}: {cancelled_ids}")
                return {'status': 'ok', 'cancelled_ids': cancelled_ids}
            else:
                response = self.kraken.cancel_all_orders()
            logger.info("Successfully cancelled all orders" + (f" for {symbol}" if symbol else ""))
            return response
        except ccxt.NetworkError as e:
            logger.error(f"Kraken API NetworkError cancelling orders: {e}")
            return {}
        except ccxt.ExchangeError as e:
            logger.error(f"Kraken API ExchangeError cancelling orders: {e}")
            return {}
        except Exception as e:
            logger.error(f"Failed to cancel orders: {e}")
            return {}

    def get_ohlcv(self, symbol: str, timeframe: str = '1h', since: int | None = None, limit: int | None = None) -> list:
        """Fetch OHLCV (candlestick) data for a symbol."""
        if not self.kraken or not self.kraken.has['fetchOHLCV']:
            logger.error("Kraken client not initialized or does not support fetchOHLCV.")
            return []
        try:
            ohlcv = self.kraken.fetch_ohlcv(symbol, timeframe, since, limit)
            logger.info(f"Successfully fetched {len(ohlcv)} OHLCV records for {symbol} ({timeframe}).")
            return ohlcv
        except Exception as e:
            logger.error(f"Failed to fetch OHLCV data for {symbol}: {e}")
            return []

# Example usage (for testing purposes, normally API keys come from config)
if __name__ == '__main__':
    # This part should use the config file when integrated
    # from ..config.kraken_config import KRAKEN_API_KEY, KRAKEN_API_SECRET 
    # For standalone testing, you might hardcode them or use environment variables
    # but ensure they are not committed to version control.
    print("Please configure API keys in config/kraken_config.py for live testing.")
    # executor = KrakenExecutor(api_key="YOUR_API_KEY", api_secret="YOUR_API_SECRET")
    # if executor.kraken:
    #     print("Balance:", executor.get_account_balance())
    #     print("BTC/USD Price:", executor.get_ticker_price('BTC/USD'))
    #     # Example: place a test order (ensure your account has test funds and you understand the risk)
    #     # test_order = executor.place_market_order('BTC/USD', 'buy', 0.0001, {'validate': True}) # Kraken test order
    #     # print("Test Order:", test_order)

