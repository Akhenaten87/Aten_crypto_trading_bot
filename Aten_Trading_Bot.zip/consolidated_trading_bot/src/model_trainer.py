import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout
from tensorflow.keras.callbacks import EarlyStopping
import logging
import os

# Assuming feature_generator is in the same directory or PYTHONPATH is set
from .feature_generator import create_features

# Configure logging
logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(module)s - %(message)s')
MODEL_DIR = "../models/"
DEFAULT_MODEL_NAME = "trading_model.h5"

def train_model(data_filepath: str, model_save_name: str = DEFAULT_MODEL_NAME, epochs: int = 50, batch_size: int = 32) -> bool:
    """
    Trains a neural network model for trading predictions.

    Args:
        data_filepath (str): Path to the OHLCV CSV data file.
        model_save_name (str): Filename to save the trained model.
        epochs (int): Number of epochs for training.
        batch_size (int): Batch size for training.

    Returns:
        bool: True if training was successful and model saved, False otherwise.
    """
    logger.info(f"Starting model training using data from: {data_filepath}")

    try:
        df = pd.read_csv(data_filepath)
        df.columns = [str(col).lower() for col in df.columns] # Ensure lowercase column names
        logger.info(f"Loaded data with shape: {df.shape}")
    except FileNotFoundError:
        logger.error(f"Data file not found: {data_filepath}")
        return False
    except Exception as e:
        logger.error(f"Error loading data from {data_filepath}: {e}")
        return False

    if df.empty:
        logger.error("Loaded data is empty. Aborting training.")
        return False

    # Create features
    try:
        df_features = create_features(df)
        logger.info(f"Features created. Shape: {df_features.shape}")
    except Exception as e:
        logger.error(f"Error creating features: {e}")
        return False

    if df_features.empty:
        logger.error("Feature DataFrame is empty. Aborting training.")
        return False

    # Create labels (example: predict if future price goes up/down/stays)
    # This is a simplified labeling strategy from the original Crypto_trading_bot/train_model.py
    # It predicts a class: 1 for buy (price increase > 0.5%), -1 for sell (price decrease < -0.5%), 0 for hold.
    # Note: The original script used sparse_categorical_crossentropy, so labels should be 0, 1, 2.
    # Let 0 = sell, 1 = hold, 2 = buy.
    if 'close' not in df_features.columns:
        logger.error("'close' column is missing after feature creation. Cannot create labels.")
        return False

    # Calculate future returns (e.g., 5 periods ahead)
    future_periods = 5
    df_features['future_close'] = df_features['close'].shift(-future_periods)
    df_features.dropna(subset=['future_close'], inplace=True) # Remove rows where future_close is NaN

    if df_features.empty:
        logger.error("DataFrame became empty after creating future_close and dropping NaNs. Not enough data for lookahead.")
        return False

    df_features['price_change_pct'] = (df_features['future_close'] / df_features['close']) - 1

    # Define thresholds for buy, sell, hold signals
    buy_threshold = 0.005  # Price increase by 0.5%
    sell_threshold = -0.005 # Price decrease by 0.5%

    def create_label(price_change):
        if price_change > buy_threshold:
            return 2  # Buy
        elif price_change < sell_threshold:
            return 0  # Sell
        else:
            return 1  # Hold

    df_features['label'] = df_features['price_change_pct'].apply(create_label)
    y = df_features['label'].values

    # Select features for X (excluding target, future price, and original OHLC if not scaled)
    # Original features used in Crypto_trading_bot: ['ema_9
    # 'ema_21
    # 'rsi
    # 'macd
    # 'signal
    # 'volume_avg
    # 'candle_size'] (close was also included but should be target or part of target creation)
    # The feature_generator.py now returns many more features.
    # We need to select a consistent set.
    feature_columns = [
        'ema_9', 'ema_21', 'rsi', 'macd', 'macd_signal_line', 'macd_diff',
        'volume_avg_10', 'candle_size', 'bb_mavg', 'bb_hband', 'bb_lband', 
        'bb_pband', 'bb_wband', 'stoch_k', 'stoch_d'
    ]
    
    # Ensure all selected feature columns exist
    missing_feature_cols = [col for col in feature_columns if col not in df_features.columns]
    if missing_feature_cols:
        logger.error(f"Missing feature columns for training: {missing_feature_cols}. Available: {df_features.columns.tolist()}")
        return False
        
    X = df_features[feature_columns].values

    if X.shape[0] != y.shape[0]:
        logger.error(f"Shape mismatch between X ({X.shape}) and y ({y.shape}). Aborting.")
        return False
    
    if X.shape[0] == 0:
        logger.error("No data available for training after processing. Aborting.")
        return False

    # Split data
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y if np.unique(y).size > 1 else None)
    logger.info(f"Training data shape: X_train {X_train.shape}, y_train {y_train.shape}")
    logger.info(f"Test data shape: X_test {X_test.shape}, y_test {y_test.shape}")

    # Build Model (similar to original, but with input_shape and adjusted output for 3 classes)
    model = Sequential([
        Dense(128, activation='relu', input_shape=(X_train.shape[1],)),
        Dropout(0.3),
        Dense(64, activation='relu'),
        Dropout(0.3),
        Dense(32, activation='relu'),
        Dense(3, activation='softmax') # 3 classes: sell, hold, buy
    ])

    model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])
    model.summary(print_fn=logger.info)

    # Train Model
    early_stopping = EarlyStopping(monitor='val_loss', patience=10, restore_best_weights=True)
    try:
        history = model.fit(X_train, y_train, 
                            epochs=epochs, 
                            batch_size=batch_size, 
                            validation_data=(X_test, y_test),
                            callbacks=[early_stopping],
                            verbose=1)
        logger.info("Model training completed.")
    except Exception as e:
        logger.error(f"Error during model fitting: {e}")
        return False

    # Save Model
    if not os.path.exists(MODEL_DIR):
        os.makedirs(MODEL_DIR)
    model_save_path = os.path.join(MODEL_DIR, model_save_name)
    try:
        model.save(model_save_path)
        logger.info(f"Training complete. Model saved as {model_save_path}")
        return True
    except Exception as e:
        logger.error(f"Error saving model to {model_save_path}: {e}")
        return False

if __name__ == '__main__':
    # Example usage:
    # Ensure you have a sample data file in ../data/
    # For example, copy one of the ohlcv_5m_*.csv files there.
    sample_data_path = "../data/ohlcv_5m_BTC-USD.csv" 
    if os.path.exists(sample_data_path):
        logger.info("Running example model training...")
        success = train_model(sample_data_path, model_save_name="test_trading_model.h5", epochs=5) # Reduced epochs for quick test
        if success:
            logger.info("Example training finished successfully.")
        else:
            logger.error("Example training failed.")
    else:
        logger.warning(f"Sample data file not found at {sample_data_path}. Skipping example training in model_trainer.py.")

