# Aten Trading Bot - README

## Overview
Aten Trading Bot is a sophisticated algorithmic trading system for cryptocurrency markets. It combines technical analysis, machine learning, and pattern recognition to generate trading signals with confidence levels.

## Features
- Multi-pair cryptocurrency trading support
- Machine learning-based signal generation
- Candlestick pattern recognition using pandas_ta
- Real-time data fetching from Kraken exchange
- Configurable trading parameters
- Comprehensive logging and monitoring

## Installation

### Prerequisites
- Python 3.11+
- Required Python packages (install via pip):
  ```
  pip install numpy==1.23.5 pandas pandas_ta scikit-learn tensorflow ccxt
  ```

### Setup
1. Extract the archive to your preferred location
2. Configure your Kraken API credentials in `config/kraken_config.py`
3. Customize trading pairs and other settings in the same file

## Usage
Run the bot with:
```
python run_bot.py
```

The bot will:
1. Download historical OHLCV data for configured trading pairs
2. Train or load the machine learning model
3. Generate trading signals with confidence levels
4. Recognize candlestick patterns
5. Output trading recommendations

## Configuration
Edit `config/kraken_config.py` to customize:
- API credentials
- Trading pairs
- Timeframes
- Model parameters
- Risk management settings

## Project Structure
- `aten_bot/` - Main package
  - `core/` - Core trading logic
    - `data_downloader.py` - OHLCV data acquisition
    - `feature_generator.py` - Technical indicator calculation
    - `model_trainer.py` - ML model training
    - `pattern_recognizer.py` - Candlestick pattern recognition
    - `signal_generator.py` - Trading signal generation
    - `kraken_executor.py` - Exchange interface
    - `main_bot.py` - Main orchestration logic
  - `config/` - Configuration files
  - `data/` - OHLCV data storage
  - `models/` - Trained ML models
- `run_bot.py` - Entry point script

## Disclaimer
This trading bot is for educational and research purposes only. Use at your own risk. Past performance is not indicative of future results.
