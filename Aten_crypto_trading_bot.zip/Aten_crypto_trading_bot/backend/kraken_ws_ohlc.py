import asyncio
import websockets
import json

# Subscribe to OHLC data (1-minute candles for BTC/USD)
async def kraken_ohlc():
    uri = "wss://ws.kraken.com"
    async with websockets.connect(uri) as ws:
        subscribe_msg = {
            "event": "subscribe",
            "pair": ["BTC/USD"],
            "subscription": {"name": "ohlc", "interval": 1}
        }
        await ws.send(json.dumps(subscribe_msg))

        while True:
            message = await ws.recv()
            data = json.loads(message)
            if isinstance(data, list) and data[2] == 'ohlc-1':
                candle = data[1]
                print(f"Candle update: Time={candle[0]}, Open={candle[1]}, High={candle[2]}, Low={candle[3]}, Close={candle[4]}")

asyncio.run(kraken_ohlc())
