import ccxt
from config import KRAKEN_API_KEY, KRAKEN_API_SECRET

# Initialize Kraken client
kraken = ccxt.kraken({
    'apiKey': KRAKEN_API_KEY,
    'secret': KRAKEN_API_SECRET,
})

def get_account_balance():
    """Fetch and return the total balance of the Kraken account."""
    try:
        balance = kraken.fetch_balance()
        return balance['total']
    except Exception as e:
        print(f"[ERROR] Failed to fetch account balance: {e}")
        return {}

def get_ticker_price(symbol):
    """Fetch and return the current price of a trading pair (e.g., 'BTC/USD')."""
    try:
        ticker = kraken.fetch_ticker(symbol)
        return ticker['last']
    except Exception as e:
        print(f"[ERROR] Failed to fetch ticker price for {symbol}: {e}")
        return None

def place_market_order(symbol, side, amount):
    """
    Place a market order.
    :param symbol: e.g., 'BTC/USD'
    :param side: 'buy' or 'sell'
    :param amount: quantity of asset to trade
    """
    try:
        order = kraken.create_market_order(symbol, side, amount)
        return order
    except Exception as e:
        print(f"[ERROR] Failed to place market order: {e}")
        return {}

def get_open_orders(symbol=None):
    """Fetch open orders. Optionally filter by symbol."""
    try:
        return kraken.fetch_open_orders(symbol)
    except Exception as e:
        print(f"[ERROR] Failed to fetch open orders: {e}")
        return []

def cancel_all_orders():
    """Cancel all open orders."""
    try:
        return kraken.cancel_all_orders()
    except Exception as e:
        print(f"[ERROR] Failed to cancel open orders: {e}")
        return {}
