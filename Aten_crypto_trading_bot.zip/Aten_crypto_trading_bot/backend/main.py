# main.py

from kraken_interface import get_account_balance

def main():
    print("Connecting to Kraken...")
    balance = get_account_balance()

    if balance:
        print("\nAccount Balance:")
        for asset, amount in balance.items():
            if amount > 0:
                print(f"{asset}: {amount}")
    else:
        print("Failed to retrieve balance.")

if __name__ == "__main__":
    main()
