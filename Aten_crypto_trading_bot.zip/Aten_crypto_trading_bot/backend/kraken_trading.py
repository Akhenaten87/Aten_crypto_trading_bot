import krakenex
from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# Initialize Kraken API client
api = krakenex.API()
api.load_key('kraken.key')  # Ensure this file contains your API credentials

@app.route('/balance', methods=['GET'])
def get_balance():
    response = api.query_private('Balance')
    return jsonify(response)

@app.route('/trade', methods=['POST'])
def place_trade():
    data = request.json
    pair = data.get('pair')
    type_ = data.get('type')  # 'buy' or 'sell'
    ordertype = data.get('ordertype')  # 'market' or 'limit'
    volume = data.get('volume')
    price = data.get('price')  # Required for limit orders

    order = {
        'pair': pair,
        'type': type_,
        'ordertype': ordertype,
        'volume': volume,
    }

    if ordertype == 'limit':
        order['price'] = price

    response = api.query_private('AddOrder', order)
    return jsonify(response)

if __name__ == '__main__':
    app.run(port=5001)
