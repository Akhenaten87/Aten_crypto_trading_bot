import time
import os
import pandas as pd
import joblib
from dataset_builder import build_dataset

MODEL_FILE = "model.pkl"
NEW_DATA_FILE = "ohlcv.csv"
PREDICTION_LOG = "prediction_log.csv"
PREDICTION_INTERVAL = 300  # every 5 minutes

def predict_new_data(model):
    if not os.path.exists(NEW_DATA_FILE):
        print(f"[Warning] '{NEW_DATA_FILE}' not found. Skipping prediction.")
        return

    df = pd.read_csv(NEW_DATA_FILE)
    if len(df) < 2:
        print("[Warning] Not enough data to make predictions.")
        return

    df['timestamp'] = pd.to_datetime(df['timestamp'])
    features, _ = build_dataset(NEW_DATA_FILE, include_labels=False)
    predictions = model.predict(features)

    actuals = (df['close'].shift(-1) > df['close']).astype(int).iloc[:-1]
    predicted = predictions[:-1]

    results = pd.DataFrame({
        'timestamp': df['timestamp'].iloc[:-1],
        'predicted': predicted,
        'actual': actuals,
        'correct': (predicted == actuals).astype(int)
    })

    if os.path.exists(PREDICTION_LOG):
        results.to_csv(PREDICTION_LOG, mode='a', header=False, index=False)
    else:
        results.to_csv(PREDICTION_LOG, index=False)

    print(f"[Logged] Predictions written to '{PREDICTION_LOG}'.")

def run_live_predictions():
    print("[Live Prediction] Started. Monitoring every 5 minutes...")
    model = joblib.load(MODEL_FILE)

    while True:
        predict_new_data(model)
        time.sleep(PREDICTION_INTERVAL)

if __name__ == "__main__":
    run_live_predictions()
