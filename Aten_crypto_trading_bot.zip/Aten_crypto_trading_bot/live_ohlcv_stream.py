import websocket
import json
import pandas as pd
import requests
from datetime import datetime
import time

# Get all tradable pairs from Kraken
def get_all_symbols():
    response = requests.get("https://api.kraken.com/0/public/AssetPairs")
    pairs = response.json()['result']
    symbols = []

    for pair in pairs:
        if ".d" not in pair:  # skip dark pool pairs
            ws_name = pairs[pair].get('wsname')
            if ws_name and "/" in ws_name:
                symbols.append(ws_name)

    return symbols

def on_message(ws, message):
    data = json.loads(message)
    if isinstance(data, list) and data[1] != 'heartbeat':
        ohlc = data[1]
        timestamp = datetime.utcfromtimestamp(float(ohlc[0]))
        open_price = float(ohlc[1])
        high_price = float(ohlc[2])
        low_price = float(ohlc[3])
        close_price = float(ohlc[4])
        volume = float(ohlc[6])
        pair = data[-1]['symbol']

        new_row = {
            'timestamp': timestamp,
            'pair': pair,
            'open': open_price,
            'high': high_price,
            'low': low_price,
            'close': close_price,
            'volume': volume
        }

        df = pd.DataFrame([new_row])
        df.to_csv('new_data.csv', mode='a', header=False, index=False)
        print(f"[{pair}] New data appended at {timestamp}")

def on_error(ws, error):
    print(f"WebSocket error: {error}")

def on_close(ws, close_status_code, close_msg):
    print("WebSocket connection closed")

def on_open(ws):
    symbols = get_all_symbols()
    subscribe_message = {
        "method": "subscribe",
        "params": {
            "channel": "ohlc",
            "symbol": symbols,
            "interval": 5
        }
    }
    ws.send(json.dumps(subscribe_message))
    print(f"Subscribed to OHLC data for {len(symbols)} pairs at 5-minute intervals")

if __name__ == "__main__":
    websocket.enableTrace(False)
    ws = websocket.WebSocketApp("wss://ws.kraken.com/v2",
                                on_open=on_open,
                                on_message=on_message,
                                on_error=on_error,
                                on_close=on_close)
    while True:
        try:
            ws.run_forever()
        except:
            print("WebSocket crashed. Restarting in 10 seconds...")
            time.sleep(10)
