import pandas as pd
from features import compute_features

def build_dataset(file_path, include_labels=True):
    df = pd.read_csv(file_path)
    df['timestamp'] = pd.to_datetime(df['timestamp'])

    # Compute features
    df = compute_features(df)

    # Add target label if needed
    if include_labels:
        df['target'] = (df['close'].shift(-1) > df['close']).astype(int)
        df.dropna(inplace=True)

    # Drop non-feature columns
    features = df.drop(columns=['timestamp', 'target'] if include_labels else ['timestamp'])

    return features, df['target'] if include_labels else None

if __name__ == "__main__":
    features, labels = build_dataset("ohlcv.csv")
    dataset = features.copy()
    dataset['target'] = labels
    dataset.to_csv("training_data.csv", index=False)
    print(f"[Saved] training_data.csv with {len(dataset)} rows.")
