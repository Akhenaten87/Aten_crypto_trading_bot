import pandas as pd
import os
from datetime import datetime

SIGNALS_FILE = "signals.csv"
TRADE_LOG_FILE = "trade_log.csv"

def load_signals():
    if not os.path.exists(SIGNALS_FILE):
        print(f"[Error] No signal file found at {SIGNALS_FILE}")
        return None
    return pd.read_csv(SIGNALS_FILE)

def simulate_trade_execution(signals):
    if signals is None or signals.empty:
        print("[Warning] No signals to execute.")
        return

    trades = []
    now = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")

    for _, row in signals.iterrows():
        trades.append({
            "timestamp": now,
            "pair": row.get("pair", "UNKNOWN"),
            "action": row.get("signal", "HOLD"),
            "price": row.get("close", 0),
            "status": "executed"
        })

    return pd.DataFrame(trades)

def log_trades(trades):
    if trades is None:
        return

    if os.path.exists(TRADE_LOG_FILE):
        trades.to_csv(TRADE_LOG_FILE, mode='a', header=False, index=False)
    else:
        trades.to_csv(TRADE_LOG_FILE, index=False)

    print(f"[Logged] Trades written to {TRADE_LOG_FILE}")

def main():
    print("[Terminal] Simulating trades from signals...")
    signals = load_signals()
    trades = simulate_trade_execution(signals)
    log_trades(trades)

if __name__ == "__main__":
    main()
