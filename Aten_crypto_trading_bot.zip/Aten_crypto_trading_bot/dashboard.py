import pandas as pd
import time
import os

PREDICTION_LOG = "prediction_log.csv"
SIGNALS_FILE = "signals.csv"

def display_dashboard():
    os.system('cls' if os.name == 'nt' else 'clear')
    print("==== 🔍 Aten Trading Bot Dashboard ====\n")

    if os.path.exists(PREDICTION_LOG):
        pred_df = pd.read_csv(PREDICTION_LOG)
        recent_preds = pred_df.tail(5)
        print("📈 Last 5 Predictions:")
        print(recent_preds.to_string(index=False))
    else:
        print("📈 No prediction log found.")

    print("\n" + "="*40 + "\n")

    if os.path.exists(SIGNALS_FILE):
        signals_df = pd.read_csv(SIGNALS_FILE)
        latest_signals = signals_df.tail(5)
        print("🚦 Last 5 Trading Signals:")
        print(latest_signals.to_string(index=False))
    else:
        print("🚦 No signals file found.")

    print("\n========================================\n")

def run_dashboard(refresh_interval=10):
    while True:
        display_dashboard()
        time.sleep(refresh_interval)

if __name__ == "__main__":
    run_dashboard()
