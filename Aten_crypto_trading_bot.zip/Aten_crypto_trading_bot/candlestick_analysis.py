import pandas as pd

class Candle:
    def __init__(self, timestamp, open_, high, low, close, volume):
        self.timestamp = timestamp
        self.open = float(open_)
        self.high = float(high)
        self.low = float(low)
        self.close = float(close)
        self.volume = float(volume)
        self.calculate_features()

    def calculate_features(self):
        self.real_body_size = abs(self.close - self.open)
        self.total_range = abs(self.high - self.low)
        self.body_to_range_ratio = self.real_body_size / self.total_range if self.total_range != 0 else 0
        self.is_bullish = self.close > self.open
        self.is_bearish = self.close < self.open
        self.upper_wick = self.high - max(self.close, self.open)
        self.lower_wick = min(self.close, self.open) - self.low
        self.upper_wick_to_body = self.upper_wick / self.real_body_size if self.real_body_size != 0 else 0
        self.lower_wick_to_body = self.lower_wick / self.real_body_size if self.real_body_size != 0 else 0

def load_candles_from_csv(file_path):
    df = pd.read_csv(file_path)
    return [Candle(*row) for row in df.itertuples(index=False)]

def is_doji(candle, threshold_ratio=0.05):
    return candle.real_body_size <= threshold_ratio * candle.total_range

def is_spinning_top(candle, min_wick_ratio=1.0, max_body_ratio=0.3):
    return (
        candle.body_to_range_ratio <= max_body_ratio and
        candle.upper_wick_to_body >= min_wick_ratio and
        candle.lower_wick_to_body >= min_wick_ratio
    )

def is_momentum_candle(current, previous, factor=2):
    return current.real_body_size >= factor * previous.real_body_size
