import pandas as pd
import ta

def compute_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()

    # Make sure there are enough rows to compute indicators
    if len(df) < 50:
        raise ValueError("Not enough rows to compute indicators. Please provide at least 50 rows.")

    # Add all standard TA indicators
    df = ta.add_all_ta_features(
        df, open="open", high="high", low="low", close="close", volume="volume", fillna=True
    )

    # Custom features
    df['price_change'] = df['close'].pct_change().fillna(0)
    df['volatility'] = (df['high'] - df['low']) / df['close']

    # Drop rows with any remaining NaNs (just in case)
    df.dropna(inplace=True)

    return df
