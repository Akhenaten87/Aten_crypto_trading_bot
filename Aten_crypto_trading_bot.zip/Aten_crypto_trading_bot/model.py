import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import joblib
from dataset_builder import build_dataset

MODEL_FILE = "model.pkl"

def train_model():
    print("[Setup] Training model...")
    features, labels = build_dataset("ohlcv.csv", include_labels=True)

    X_train, X_test, y_train, y_test = train_test_split(features, labels, test_size=0.3, random_state=42)
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)

    predictions = model.predict(X_test)
    accuracy = accuracy_score(y_test, predictions)
    print(f"[Result] Accuracy: {accuracy:.2%}")

    joblib.dump(model, MODEL_FILE)
    print(f"[Saved] Model saved to {MODEL_FILE}")
    return model

if __name__ == "__main__":
    train_model()

