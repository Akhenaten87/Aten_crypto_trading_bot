from candlestick_analysis import load_candles_from_csv, is_doji, is_spinning_top, is_momentum_candle
import pandas as pd
import os

SIGNAL_LOG = "signals.csv"

def generate_signal(candle_list):
    signals = []

    for i in range(2, len(candle_list)):
        prev2, prev1, current = candle_list[i-2], candle_list[i-1], candle_list[i]

        signal = None

        # Example bullish reversal pattern: Bullish Engulfing
        if prev1.is_bearish and current.is_bullish and current.close > prev1.open and current.open < prev1.close:
            signal = ('Bullish Engulfing', 'Buy')

        # Example bearish reversal pattern: Bearish Engulfing
        elif prev1.is_bullish and current.is_bearish and current.close < prev1.open and current.open > prev1.close:
            signal = ('Bearish Engulfing', 'Sell')

        # Doji signal (indecision)
        elif is_doji(current):
            signal = ('Doji', 'Hold')

        # Spinning Top signal (uncertainty)
        elif is_spinning_top(current):
            signal = ('Spinning Top', 'Hold')

        # Momentum continuation (bullish)
        elif is_momentum_candle(current, prev1) and current.is_bullish:
            signal = ('Bullish Momentum', 'Buy')

        # Momentum continuation (bearish)
        elif is_momentum_candle(current, prev1) and current.is_bearish:
            signal = ('Bearish Momentum', 'Sell')

        if signal:
            signals.append({
                "timestamp": current.timestamp,
                "pattern": signal[0],
                "action": signal[1],
                "confidence": "High"
            })

    return signals

def save_signals_to_csv(signals, filename=SIGNAL_LOG):
    df = pd.DataFrame(signals)
    if os.path.exists(filename):
        df.to_csv(filename, mode='a', header=False, index=False)
    else:
        df.to_csv(filename, index=False)

if __name__ == "__main__":
    candles = load_candles_from_csv("ohlcv.csv")
    signals = generate_signal(candles)
    save_signals_to_csv(signals)
    print(f"✅ Signals written to {SIGNAL_LOG} ({len(signals)} entries)")
