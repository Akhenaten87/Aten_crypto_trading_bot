# candlestick_features.py

import pandas as pd
import talib

def extract_candlestick_features(df):
    """
    Extract candlestick pattern features from OHLCV DataFrame.
    """
    open_ = df['open']
    high = df['high']
    low = df['low']
    close = df['close']

    patterns = {
        'CDL_DOJI': talib.CDLDOJI(open_, high, low, close),
        'CDL_HAMMER': talib.CDLHAMMER(open_, high, low, close),
        'CDL_ENGULFING': talib.CDLENGULFING(open_, high, low, close),
        # Add more patterns as needed
    }

    for name, pattern in patterns.items():
        df[name] = pattern

    return df
