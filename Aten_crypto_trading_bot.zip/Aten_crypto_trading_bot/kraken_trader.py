import krakenex
import pandas as pd
import time
import os

# Load API credentials
api = krakenex.API()
api.load_key('kraken.key')

SIGNALS_FILE = "signals.csv"
TRADE_LOG_FILE = "trade_log.csv"

def load_signals():
    if not os.path.exists(SIGNALS_FILE):
        print(f"[Error] No signal file found at {SIGNALS_FILE}")
        return None
    return pd.read_csv(SIGNALS_FILE)

def place_order(pair, action, volume):
    order_type = 'buy' if action.lower() == 'buy' else 'sell'
    try:
        response = api.query_private('AddOrder', {
            'pair': pair,
            'type': order_type,
            'ordertype': 'market',
            'volume': volume
        })
        if response['error']:
            print(f"[Error] {response['error']}")
            return None
        return response['result']['txid'][0]
    except Exception as e:
        print(f"[Exception] {e}")
        return None

def execute_trades():
    signals = load_signals()
    if signals is None or signals.empty:
        print("[Info] No signals to process.")
        return

    for index, row in signals.iterrows():
        pair = row.get("pair")
        action = row.get("signal")
        volume = row.get("volume", 0.01)  # Default volume; adjust as needed

        print(f"[Trade] Placing {action} order for {pair} with volume {volume}")
        txid = place_order(pair, action, volume)
        if txid:
            log_trade(pair, action, volume, txid)

def log_trade(pair, action, volume, txid):
    now = time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime())
    trade_data = {
        'timestamp': now,
        'pair': pair,
        'action': action,
        'volume': volume,
        'txid': txid
    }
    df = pd.DataFrame([trade_data])
    if os.path.exists(TRADE_LOG_FILE):
        df.to_csv(TRADE_LOG_FILE, mode='a', header=False, index=False)
    else:
        df.to_csv(TRADE_LOG_FILE, index=False)
    print(f"[Logged] Trade executed and logged with txid: {txid}")

if __name__ == "__main__":
    execute_trades()
