import pandas as pd

def check_ohlcv_data(file_path='ohlcv.csv'):
    print("[Check] Loading OHLCV data...")
    try:
        df = pd.read_csv(file_path)
    except FileNotFoundError:
        print(f"[Error] File '{file_path}' not found.")
        return

    print(f"[Info] Data loaded. Total rows: {len(df)}")

    # Check for missing values
    missing = df.isnull().sum()
    print("\n[Check] Missing values:")
    print(missing)

    # Check for correct columns
    expected_cols = {'timestamp', 'open', 'high', 'low', 'close', 'volume'}
    actual_cols = set(df.columns)
    if expected_cols != actual_cols:
        print(f"[Warning] Columns do not match expected: {expected_cols}")
        print(f"[Current Columns] {actual_cols}")

    # Check date range and continuity
    df['timestamp'] = pd.to_datetime(df['timestamp'], errors='coerce')
    df.sort_values('timestamp', inplace=True)

    if df['timestamp'].isnull().any():
        print("[Warning] Some timestamp values could not be parsed.")

    print(f"\n[Preview] First 5 rows:\n{df.head()}")
    print(f"\n[Preview] Last 5 rows:\n{df.tail()}")

if __name__ == "__main__":
    check_ohlcv_data()
