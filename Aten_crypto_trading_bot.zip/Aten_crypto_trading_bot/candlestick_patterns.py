import pandas as pd
import numpy as np

import pandas as pd

def extract_candlestick_features(df):
    df = df.copy()

    df['real_body_size'] = (df['close'] - df['open']).abs()
    df['total_range'] = (df['high'] - df['low']).abs()
    df['body_to_range_ratio'] = df['real_body_size'] / df['total_range'].replace(0, 1)
    df['is_bullish_candle'] = df['close'] > df['open']
    df['is_bearish_candle'] = df['close'] < df['open']

    df['upper_wick_size'] = df.apply(
        lambda row: row['high'] - max(row['open'], row['close']), axis=1)
    df['lower_wick_size'] = df.apply(
        lambda row: min(row['open'], row['close']) - row['low'], axis=1)

    df['upper_wick_to_body_ratio'] = df['upper_wick_size'] / df['real_body_size'].replace(0, 1)
    df['lower_wick_to_body_ratio'] = df['lower_wick_size'] / df['real_body_size'].replace(0, 1)

    df['CDL_Doji'] = (df['real_body_size'] < 0.1 * df['total_range']).astype(int)
    df['CDL_SpinningTop'] = ((df['real_body_size'] > 0.1 * df['total_range']) &
                             (df['upper_wick_size'] > df['real_body_size']) &
                             (df['lower_wick_size'] > df['real_body_size'])).astype(int)
    df['CDL_Momentum'] = df['real_body_size'].rolling(2).apply(
        lambda x: 1 if len(x) == 2 and x[1] > 2 * x[0] else 0, raw=True).fillna(0).astype(int)

    return df

class CandleAnalyzer:
    def __init__(self, df):
        self.df = df.copy()
        self.add_candle_features()

    def add_candle_features(self):
        df = self.df
        df['real_body'] = (df['close'] - df['open']).abs()
        df['total_range'] = df['high'] - df['low']
        df['body_to_range_ratio'] = df['real_body'] / df['total_range'].replace(0, np.nan)
        df['is_bullish'] = df['close'] > df['open']
        df['is_bearish'] = df['close'] < df['open']

        df['upper_wick'] = np.where(df['is_bullish'], df['high'] - df['close'], df['high'] - df['open'])
        df['lower_wick'] = np.where(df['is_bullish'], df['open'] - df['low'], df['close'] - df['low'])

        df['upper_wick_to_body'] = df['upper_wick'] / df['real_body'].replace(0, np.nan)
        df['lower_wick_to_body'] = df['lower_wick'] / df['real_body'].replace(0, np.nan)
        self.df = df

    def is_doji(self, row, threshold=0.05):
        return row['real_body'] < threshold * row['total_range']

    def is_spinning_top(self, row):
        return row['real_body'] > 0.05 and row['real_body'] < 0.3 * row['total_range'] and \
               row['upper_wick'] > row['real_body'] and row['lower_wick'] > row['real_body']

    def is_momentum_candle(self, current, previous):
        return current['real_body'] >= 2 * previous['real_body']

    def detect_patterns(self):
        patterns = []
        df = self.df.reset_index(drop=True)

        for i in range(len(df)):
            row = df.iloc[i]
            pattern = None

            if self.is_doji(row):
                pattern = 'Doji'
            elif self.is_spinning_top(row):
                pattern = 'Spinning Top'
            elif i > 0 and self.is_momentum_candle(row, df.iloc[i-1]):
                pattern = 'Momentum Candle'

            patterns.append(pattern or 'None')

        self.df['pattern'] = patterns
        return self.df
