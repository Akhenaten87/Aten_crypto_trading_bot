import pandas as pd
from features import compute_features

df = pd.read_csv('ohlcv.csv')
df = compute_features(df)
print(df[['price_change', 'volatility']].head())
