import pandas as pd
import os
from candlestick_patterns import CandleAnalyzer

# === Config ===
DATA_DIR = "data"  # Directory with subfolders for each symbol (e.g., BTCUSD/ohlcv.csv)
FILENAME = "ohlcv.csv"  # Standard OHLCV filename in each pair's folder

def analyze_all_pairs():
    print("[Pattern Analyzer] Starting scan of all trading pairs...")
    
    for symbol_dir in os.listdir(DATA_DIR):
        symbol_path = os.path.join(DATA_DIR, symbol_dir, FILENAME)
        if not os.path.isfile(symbol_path):
            continue

        try:
            df = pd.read_csv(symbol_path)
            analyzer = CandleAnalyzer(df)
            result = analyzer.detect_patterns()

            print(f"\n[Pattern Analysis Preview] — {symbol_dir}")
            print(result[['timestamp', 'open', 'high', 'low', 'close', 'pattern']].tail(10))
        
        except Exception as e:
            print(f"[Error] Failed analyzing {symbol_dir}: {e}")

if __name__ == "__main__":
    analyze_all_pairs()
